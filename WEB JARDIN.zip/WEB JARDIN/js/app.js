
window.onload = function () {
  let correctAnswers = 0;

  document.getElementById("start-btn").addEventListener("click", () => {
    document.getElementById("quiz-section").classList.remove("hidden");
    document.getElementById("score-section").classList.add("hidden");
    generateQuestions();
  });

  document.getElementById("submit-answers").addEventListener("click", () => {
    const inputs = document.querySelectorAll("#questions-container input");
    correctAnswers = 0;
    inputs.forEach(input => {
      const correct = parseInt(input.dataset.answer);
      const value = parseInt(input.value);
      if (value === correct) {
        correctAnswers++;
        input.style.borderColor = "green";
      } else {
        input.style.borderColor = "red";
      }
    });
    document.getElementById("score-section").classList.remove("hidden");
  });

  document.getElementById("check-grade").addEventListener("click", () => {
    const autoScore = Math.round((correctAnswers / 5) * 100);
    const resultMsg = document.getElementById("result-msg");
    const emoji = autoScore >= 60 ? "🎉" : "😢";

    resultMsg.innerHTML = `Obtuviste ${autoScore} puntos. Resultado: <strong>${autoScore >= 60 ? "Aprobado" : "Reprobado"}</strong> ${emoji}`;

    resultMsg.style.color = autoScore >= 60 ? "green" : "red";
  });
function generateQuestions() {
  const container = document.getElementById("questions-container");
  container.innerHTML = "";
  for (let i = 1; i <= 5; i++) {
    const num1 = Math.floor(Math.random() * 10);
    const num2 = Math.floor(Math.random() * 10);
    const div = document.createElement("div");
    div.className = "question";
    div.innerHTML = `
      <label><strong>Ejercicio ${i}:</strong> ¿Cuánto es ${num1} + ${num2}?</label>
      <input type="number" data-answer="${num1 + num2}" />
    `;
    container.appendChild(div);
  }
}

};
