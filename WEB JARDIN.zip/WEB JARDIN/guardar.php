
<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "jardin";

$conn = new mysqli($host, $user, $password, $db);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$id = $_POST['id_estudiante'];
$nota = $_POST['nota'];

$sql = "INSERT INTO estudiantes (id_estudiante, nota) VALUES ('$id', '$nota')";
if ($conn->query($sql) === TRUE) {
    echo "Datos guardados correctamente. <a href='index.html'>Volver</a>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>
